package facade;

public enum TipoPasta 
{
    COLABORADOR,
    RODRIGUES
}