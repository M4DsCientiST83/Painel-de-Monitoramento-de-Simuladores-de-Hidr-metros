package util;

import net.sourceforge.tess4j.*;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;

public class UtilOCR 
{
    
    public static String extrairApenasDigitos(BufferedImage imagem) throws TesseractException 
    {
        ITesseract tesseract = new Tesseract();
        tesseract.setDatapath("C:/Program Files/Tesseract-OCR/tessdata");
        tesseract.setLanguage("por");
        tesseract.setLanguage("eng");
        tesseract.setPageSegMode(7);
        tesseract.setOcrEngineMode(1);
        tesseract.setTessVariable("tessedit_char_whitelist", "0123456789");
        
        String resultado = tesseract.doOCR(imagem);
        return resultado.replaceAll("[^0-9]", "").trim();
    }
    
    public static BufferedImage matParaBufferedImage(Mat mat) 
    {
        MatOfByte mob = new MatOfByte();
        Imgcodecs.imencode(".png", mat, mob);
        try 
        {
            return ImageIO.read(new ByteArrayInputStream(mob.toArray()));
        } 
        catch (IOException e) 
        {
            return null;
        }
    }
}