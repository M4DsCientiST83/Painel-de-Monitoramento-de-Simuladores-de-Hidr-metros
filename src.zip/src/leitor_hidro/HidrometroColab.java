package leitor_hidro;

import util.Circulo;
import util.UtilOCR;
import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;
import net.sourceforge.tess4j.TesseractException;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;


public class HidrometroColab 
{
    
    public Rect obterRegiaDoDisplay(Mat imagem) 
    {
        int altura = imagem.rows();
        int largura = imagem.cols();
        
        return new Rect(
            largura / 4,
            altura / 8,
            largura / 2,
            altura / 5
        );
    }
    
    public String extrairDigitos(Mat regiao) throws TesseractException 
    {
        Mat processada = preprocessar(regiao);
        return realizarOCR(processada);
    }
    
    public List<Circulo> identificarMostradores(Mat imagem) 
    {
        List<Circulo> mostradores = new ArrayList<>();
        
        Mat cinza = new Mat();
        Imgproc.cvtColor(imagem, cinza, Imgproc.COLOR_BGR2GRAY);
        
        Mat circulos = new Mat();
        Imgproc.HoughCircles(
            cinza, circulos, Imgproc.HOUGH_GRADIENT, 1,
            cinza.rows() / 8, 100, 30, 15, 50
        );
        
        for (int i = 0; i < circulos.cols(); i++) 
        {
            double[] c = circulos.get(0, i);
            mostradores.add(new Circulo(
                new Point(Math.round(c[0]), Math.round(c[1])),
                (int) Math.round(c[2])
            ));
        }
        
        return mostradores;
    }
    
    private Mat preprocessar(Mat regiao) 
    {
        Mat binaria = new Mat();
        Imgproc.threshold(regiao, binaria, 0, 255, 
            Imgproc.THRESH_BINARY + Imgproc.THRESH_OTSU);
        return binaria;
    }
    
    private String realizarOCR(Mat imagem) throws TesseractException 
    {
        BufferedImage bi = UtilOCR.matParaBufferedImage(imagem);
        return UtilOCR.extrairApenasDigitos(bi);
    }
}